package com.masai;

public class ServiceBean {

	public int calculate(int x, int y) {
		
		System.out.println("Adding two numbers");
		
		return x+y;
	
	}

}
